const AWS = require('aws-sdk');
const iotdata = new AWS.IotData({ endpoint: 'a3plgd8pfckwr2-ats.iot.ap-southeast-1.amazonaws.com' });

exports.handler = async (event) => {
    const testParams = {
        topic: 'controller/output',  // Your test MQTT topic
        payload: JSON.stringify({ message: 'Hello' }),  // Test message
        qos: 0
    };

    try {
        await iotdata.publish(testParams).promise();
        console.log('Published test message: "Hello" to topic:', testParams.topic);
    } catch (err) {
        console.error('Failed to publish test message to IoT Core:', err);
    }

    // Processing DynamoDB stream records
    for (const record of event.Records) {
        if (record.eventName === 'INSERT') {
            const newImage = AWS.DynamoDB.Converter.unmarshall(record.dynamodb.NewImage);

            const params = {
                topic: 'controller/output',  // Your MQTT topic
                payload: JSON.stringify(newImage),  // Convert DynamoDB item to JSON
                qos: 0
            };

            try {
                await iotdata.publish(params).promise();
                console.log('Published to topic:', params.topic);
            } catch (err) {
                console.error('Failed to publish to IoT Core:', err);
            }
        }
    }
};
